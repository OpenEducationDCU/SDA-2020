FragmentAlertDialog- Lecture 13

This app is a part of CS65 - Smartphone Programming class at Dartmouth. Visit this page for details about this app- 
http://www.cs.dartmouth.edu/~xingdong/Teaching/CS65/lecture13/lecture13.html
